#!/bin/bash

for f in *.png
do
  convert $f $f.txt
  echo $f
  (tail -n +2 $f.txt | sed --expression='s/^[^#]*//' | sort | uniq -c | sort -nr) >$f.stats
  rm $f.txt
done
